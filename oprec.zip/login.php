<?php
session_start();
require "koneksi.php";
$sql="$koneksi, SELECT * FROM `user`";

isset("submit"){
    $username=$_POST['username'];
    $pass=$_POST['password'];

    $row = mysqli_fetch_assoc("user");
    if($username == $row){
        
    }else{
        echo"username tak sesuai";
    }

    $_SESSION=$username;

    if($pass){
        header('location: index.php');
    }else{
        echo"login gagal";
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Login Petugas</h1>
    <form action="" method="post">
        Username: <input type="text" value="">
        <br>
        password: <input type="password" value="">
        <br>
        <input type="submit" value="Login">
    </form>
    
</body>
</html>